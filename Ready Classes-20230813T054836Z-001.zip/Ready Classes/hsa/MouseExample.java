/*Example usage of MouseInput*/
import java.awt.*;
import hsa.*;

public class MouseExample
{ static MouseConsole c;
  public static void main(String[] args){
    c = new MouseConsole();
    
    for (;;){
      //Test normal mouse movement, warning the mouse has to move once for it to update the positions
      for (int i = 0; i < 2000000; i++);
      c.println(c.getLastX() + " " + c.getLastY() );
    }
    
    /*
    for (;;){
      //Print whether the mouse is down or not
      for (int i = 0; i < 2000000; i++);
      c.println(c.isClicked() );
    }*/
    /*
    for (;;){
      //Don't do anything until a mouse is clicked
      c.waitForClick();
      c.println(c.getLastX() + " " + c.getLastY() );
    }*/
  }
}